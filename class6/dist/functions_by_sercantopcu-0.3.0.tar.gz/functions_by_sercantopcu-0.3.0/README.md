# Instructions

#### This is our test project. 

#### Please install this package
```
pip install functions-by-sercantopcu
```


#### You can also install older packages
```
pip install functions-by-sercantopcu==VERSION_NUMBER
```